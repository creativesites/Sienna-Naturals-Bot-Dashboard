import React from "react";

const BlankPageLayer = () => {
  return <div></div>;
};

export default BlankPageLayer;
